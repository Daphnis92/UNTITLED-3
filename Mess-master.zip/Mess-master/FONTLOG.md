# FONTLOG for Mess
This file provides detailed information on the evolutions of the Mess typeface.

## Basic Font Information
Mess is a typeface designed by Tezzo Suzuki.

## Information for Contributors
See the project website for the current trunk and the various branches:
https://gitlab.com/velvetyne/Mess

## ChangeLog
When you make modifications, be sure to add a description of your changes,
following the format of the other entries, to the start of this section.

**2020.10.01 (Tezzo Suzuki) Mess v1.0**
Initial push of "Mess" font

## Acknowledgements
When you make modifications, be sure to add your name (N), email (E),
web-address (W) and description (D). This list is sorted by last name in
alphabetical order.

N: Tezzo Suzuki
E: info@tezzosuzuki.com
W: http://tezzosuzuki.com/
D: Designer
